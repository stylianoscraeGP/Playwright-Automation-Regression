function t(t){if("keys"in Object&&"function"==typeof Object.keys)return Object.keys(t);const e=[];for(const n in t)Object.prototype.hasOwnProperty.call(t,n)&&e.push(n);return e}export{t as k};
